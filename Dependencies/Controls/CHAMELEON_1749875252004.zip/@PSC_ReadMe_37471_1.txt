Title: CHAMELEON BUTTON 2.0.6 B - the best command button ever strikes back! (UPDATED, BRANCH)
Description: THE GREAT CHAMELEON BUTTON STRIKES BACK!!! 
 
THIS TIME WITH LOADS OF NEW FEATURES ADDED!
IT NOW HAS 13 DIFFERENT BUTTON STYLES, SUPPORTS PICTURES, FONT EFFECTS AND MUCH MORE!
SEVERAL BUGS HAVE BEEN CORRECTED AND A LOT OF FIXES WERE DONE TO THE CODE.
ONCE YOU TRY IT, YOU WILL NEVER WANT ANYTHING ELSE THAN THIS! 
ADD STYLE TO YOUR APPLICATIONS, ADD VALUE TO THEM, BUILD MARVELOUS USER INTERFACES AND IMPRESS THE USERS OF YOUR PROGRAM. 
 
HAVE FUN!!!
 
 UPDATE: Some bugs/flaws fixed in ver 2.0.5 & 2.0.6 
 
JUNE 08, 2003 >> A BRANCHED VERSION HAS BEEN POSTED TO FIX SOME CRITICAL BUGS, THIS IS STILL FOR NO COMMERCIAL USE. 
MORE INFO AT http://gonchuki.8m.com
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=37471&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
